import React from 'react'

function HomeDetails() {
  return (

    <div>
        <h1 className='text-5xl font-bold my-3'>Find Your Next <br />Stay <br /> <span className="text-sky-400">effortlessly.</span></h1>
        <p className='text-gray-500'>Discovered verfied listing,exclusive deals, and best price guarantee for hotels worldwide</p>
    </div>
  )
}

export default HomeDetails