import React from 'react'

function OwnerDashboard() {
  return (
    <div>Owner</div>
  )
}

export default OwnerDashboard