import React from 'react'
import OwnerNavBar from './common/OwnerNavBar'

function OwnerHomePage() {
  return (
    <>
    {/* <div className='flex'>

        <div>hello</div>
        <div>
            <div>
                <OwnerNavBar />
            </div>
            <div>Hello</div>
        </div>
    </div> */}
    </>
  )
}

export default OwnerHomePage