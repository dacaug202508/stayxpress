import React from "react";
import { Outlet } from "react-router-dom";
import OwnerNavBar from "./OwnerNavBar";
import OwnerSideBar from "./OwnerSideBar";
import { BiBell } from "react-icons/bi";
import { RxAvatar } from "react-icons/rx";

function OwnerLayout() {
  return (
    <>
      {/* MOBILE BLOCK */}
      <div className="md:hidden h-screen flex flex-col items-center justify-center bg-gray-50 text-center px-6">
        <h1 className="text-xl font-semibold mb-2">
          Desktop Required
        </h1>
        <p className="text-gray-500 text-sm">
          This dashboard is optimized for tablet and desktop screens.
        </p>
      </div>

      {/* DESKTOP / TABLET */}
      <div className="hidden md:flex min-h-screen bg-gray-50">
        {/* SIDEBAR */}
        <aside className="
          w-64
          bg-white
          h-screen
          sticky
          top-0
          shadow-sm
        ">
          <OwnerSideBar />
        </aside>

        {/* MAIN */}
        <div className="flex flex-col flex-1">
          {/* HEADER */}
          <header className="
            h-16
            bg-white
            px-6
            flex
            items-center
            justify-between
            shadow-sm
          ">
            {/* LEFT */}
            <OwnerNavBar />

            {/* RIGHT */}
            <div className="flex items-center gap-4">
              <BiBell
                size={20}
                className="cursor-pointer text-gray-600 hover:text-gray-800 transition"
              />

              <div className="flex items-center gap-2 bg-gray-100 px-3 py-1.5 rounded-full">
                <RxAvatar size={20} />
                <span className="text-sm font-medium text-gray-700">
                  Admin
                </span>
              </div>
            </div>
          </header>

          {/* CONTENT */}
          <main className="
            flex-1
            p-6
            overflow-y-auto
            bg-gray-50
          ">
            <Outlet />
          </main>
        </div>
      </div>
    </>
  );
}

export default OwnerLayout;
