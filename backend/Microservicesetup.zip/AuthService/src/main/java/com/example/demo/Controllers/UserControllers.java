package com.example.demo.Controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Services.UserService;
import com.example.demo.entities.LoginDto;
import com.example.demo.entities.UserEntity;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("/auth")
public class UserControllers {


	@Autowired
	private UserService userService;

	
	
	
	@PostMapping("/register")
	public UserEntity registerUser(@RequestBody UserEntity user) {
		UserEntity savedUser = null;
		try {
			
			 savedUser =  userService.saveUser(user);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return savedUser;
	}
	
	@GetMapping("/getall")
	public List<UserEntity> getAllUsers()
	{
		List<UserEntity> allUsers = null;
		try {
			
			 allUsers =  userService.allUsers();
			System.out.println(allUsers);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return allUsers;
	}
	
	@PostMapping("/login")
	public String login(@RequestBody LoginDto user) {
		String token = "";
		try {
			System.out.println(user.getPassword());
			 token = userService.authenticate(user);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return token;
	}
	
	
}
